<?php

  $lang["api_username"] = "Remote API username (XML-RPC)";
  $lang["api_password"] = "Remote API password (XML-RPC)";

?>
