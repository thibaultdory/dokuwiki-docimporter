<?php

  $lang["api_username"] = "Nom d'utilisateur API XML-RPC";
  $lang["api_password"] = "Mot de passe API XML-RPC";

?>

