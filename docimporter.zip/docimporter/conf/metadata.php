<?php 

 $meta["api_username"] = array('string');
 $meta["api_password"] = array('password');

?>
