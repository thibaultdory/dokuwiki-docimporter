<?php

 $conf["api_username"] = "";
 $conf["api_password"] = "";

?>
